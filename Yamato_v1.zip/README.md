# Yamato

Render: Build `npm install`, Start `npm start`.

MVP: accounts, real video/thumbnail uploads, home feed, views and likes.

Important: free Render storage is ephemeral; use persistent external storage/database before public launch.
